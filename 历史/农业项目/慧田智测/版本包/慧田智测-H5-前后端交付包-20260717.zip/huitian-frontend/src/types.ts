export type HealthResponse = {
  app: string
  status: 'ok' | 'degraded' | string
  database: string
  mqtt: string
  timestamp: string
}

export type Farm = {
  id: number
  name: string
  location: string
  description: string
  created_at: string
}

export type Plot = {
  id: number
  farm_id: number
  name: string
  crop_type: string
  area: number
  created_at: string
}

export type Device = {
  id: number
  plot_id: number
  device_code: string
  name: string
  device_type: string
  communication_type: string
  is_online: boolean
  last_seen_at: string | null
  created_at: string
}

export type SensorReading = {
  id: number
  device_id: number
  metric: string
  value: number
  unit: string
  quality: 'good' | 'suspect' | 'bad' | string
  recorded_at: string
  received_at: string
}

export type PlotMetricSummary = {
  metric: string
  count: number
  minimum: number
  maximum: number
  average: number
  latest: number
  unit: string
}

export type AlertStatus = 'open' | 'acknowledged' | 'resolved'
export type AlertSeverity = 'info' | 'warning' | 'critical'

export type Alert = {
  id: number
  rule_id: number
  device_id: number
  reading_id: number
  severity: AlertSeverity | string
  message: string
  status: AlertStatus | string
  created_at: string
  updated_at: string
}

export type CommandType = 'pump_on' | 'pump_off' | 'light_on' | 'light_off'
export type CommandStatus = 'pending' | 'sent' | 'acknowledged' | 'succeeded' | 'failed'

export type DeviceCommand = {
  id: number
  device_id: number
  command_type: CommandType | string
  parameters_json: Record<string, unknown>
  status: CommandStatus | string
  created_at: string
  updated_at: string
}

export type DiagnosisRecord = {
  id: number
  plot_id: number
  image_path: string
  crop_type: string
  growth_stage: string
  health_status: string
  result_text: string
  created_at: string
}

export type TelemetryPayload = {
  device_code: string
  recorded_at: string
  readings: Array<{
    metric: string
    value: number
    unit: string
    quality: 'good' | 'suspect' | 'bad'
  }>
}

export type TelemetryIngestResponse = {
  device_code: string
  saved_count: number
  alert_count: number
  readings: SensorReading[]
}

export type RealtimeEvent = {
  event: string
  data: Record<string, unknown>
  receivedAt: string
}
