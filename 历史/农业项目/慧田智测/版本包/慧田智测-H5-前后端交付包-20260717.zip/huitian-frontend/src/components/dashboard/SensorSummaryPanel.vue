<script setup lang="ts">
import { formatNumber } from '../../format'
import { labelMetric, labelUnit } from '../../labels'
import type { PlotMetricSummary } from '../../types'

defineProps<{
  summaries: PlotMetricSummary[]
  actionBusy: boolean
}>()

defineEmits<{
  sendRisk: []
}>()
</script>

<template>
  <article class="panel panel--wide js-entrance">
    <div class="section-heading">
      <div>
        <span class="panel__label">传感器汇总</span>
        <h2>地块环境指标</h2>
      </div>
      <button class="button button--secondary" type="button" :disabled="actionBusy" @click="$emit('sendRisk')">
        上报告警数据
      </button>
    </div>
    <div v-if="summaries.length === 0" class="empty-state">
      <strong>还没有传感器数据</strong>
      <p>点击“上报正常数据”可以立即生成一组演示数据。</p>
    </div>
    <div v-else class="metric-grid">
      <div v-for="summary in summaries" :key="summary.metric" class="metric-card">
        <span>{{ labelMetric(summary.metric) }}</span>
        <strong>{{ formatNumber(summary.latest) }} {{ labelUnit(summary.unit) }}</strong>
        <small>均值 {{ formatNumber(summary.average) }}，范围 {{ formatNumber(summary.minimum) }} 到 {{ formatNumber(summary.maximum) }}</small>
      </div>
    </div>
  </article>
</template>
