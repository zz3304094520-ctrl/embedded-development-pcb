<script setup lang="ts">
import { commandLabels, labelCommand, labelCommandStatus } from '../../labels'
import type { CommandType, Device, DeviceCommand } from '../../types'

defineProps<{
  devices: Device[]
  commands: DeviceCommand[]
  selectedCommandDevice: Device | null
  canSubmit: boolean
  actionBusy: boolean
}>()

const commandDeviceId = defineModel<number | null>('commandDeviceId', { required: true })
const commandType = defineModel<CommandType>('commandType', { required: true })
const commandDuration = defineModel<number>('commandDuration', { required: true })

defineEmits<{
  submitCommand: []
}>()
</script>

<template>
  <article class="panel js-entrance">
    <div class="section-heading">
      <div>
        <span class="panel__label">控制</span>
        <h2>设备命令</h2>
      </div>
    </div>
    <form class="form-stack" @submit.prevent="$emit('submitCommand')">
      <label>
        <span>设备</span>
        <select v-model.number="commandDeviceId" name="command_device_id" autocomplete="off">
          <option v-for="device in devices" :key="device.id" :value="device.id">
            {{ device.name }}
          </option>
        </select>
      </label>
      <label>
        <span>命令</span>
        <select v-model="commandType" name="command_type" autocomplete="off">
          <option v-for="(label, value) in commandLabels" :key="value" :value="value">
            {{ label }}
          </option>
        </select>
      </label>
      <label v-if="commandType === 'pump_on' || commandType === 'light_on'">
        <span>持续时间，秒</span>
        <input v-model.number="commandDuration" name="duration_seconds" type="number" inputmode="numeric" autocomplete="off" min="1" max="3600" />
      </label>
      <button class="button button--primary" type="submit" :disabled="!canSubmit">
        {{ actionBusy ? '发送中…' : '创建命令' }}
      </button>
      <p class="form-note">
        {{ selectedCommandDevice ? `将发送到 ${selectedCommandDevice.device_code}` : '请选择设备' }}
      </p>
    </form>
    <div class="command-list">
      <div v-for="command in commands" :key="command.id">
        <strong>{{ labelCommand(command.command_type) }}</strong>
        <span>{{ labelCommandStatus(command.status) }}</span>
      </div>
    </div>
  </article>
</template>
