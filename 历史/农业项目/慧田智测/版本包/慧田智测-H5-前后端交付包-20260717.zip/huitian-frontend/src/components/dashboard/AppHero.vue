<script setup lang="ts">
import { computed, shallowRef, useTemplateRef } from 'vue'

const props = defineProps<{
  systemStatusLabel: string
  fieldRiskLabel: string
  wsConnected: boolean
  activeAlertCount: number
  criticalAlertCount: number
}>()

const statusClasses = computed(() => ({
  'is-risk': props.criticalAlertCount > 0,
  'is-warning': props.activeAlertCount > 0 && props.criticalAlertCount === 0,
}))

const headlineField = useTemplateRef<HTMLElement>('headlineField')
const pointerActive = shallowRef(false)

function handlePointerMove(event: PointerEvent): void {
  const field = headlineField.value
  if (!field) return

  const rect = field.getBoundingClientRect()
  const x = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width))
  const y = Math.min(1, Math.max(0, (event.clientY - rect.top) / rect.height))

  field.style.setProperty('--hero-x', `${x * 100}%`)
  field.style.setProperty('--hero-y', `${y * 100}%`)
  field.style.setProperty('--hero-drift-x', `${(x - 0.5) * 22}px`)
  field.style.setProperty('--hero-drift-y', `${(y - 0.5) * 14}px`)
  field.style.setProperty('--hero-tilt-x', `${(0.5 - y) * 5}deg`)
  field.style.setProperty('--hero-tilt-y', `${(x - 0.5) * 7}deg`)
}

function handlePointerEnter(event: PointerEvent): void {
  pointerActive.value = true
  handlePointerMove(event)
}

function handlePointerLeave(): void {
  pointerActive.value = false
}
</script>

<template>
  <section id="top" class="hero js-entrance" aria-labelledby="page-title">
    <div
      ref="headlineField"
      class="hero__scene"
      :class="{ 'is-pointer-active': pointerActive }"
      @pointerenter="handlePointerEnter"
      @pointermove="handlePointerMove"
      @pointerleave="handlePointerLeave"
    >
      <div class="hero__visual" aria-hidden="true">
        <span class="hero__photo"></span>
        <span class="hero__aurora"></span>
        <span class="hero__code-layer"></span>
        <span class="hero__particle hero__particle--one"></span>
        <span class="hero__particle hero__particle--two"></span>
        <span class="hero__particle hero__particle--three"></span>
        <span class="hero__particle hero__particle--four"></span>
        <span class="hero__particle hero__particle--five"></span>
      </div>

      <div class="hero__center">
        <p class="kicker">智慧农业现场中台</p>
        <h1 id="page-title">慧田智测</h1>
        <p class="hero__english">From Field to Decision</p>
        <p class="hero__lead">
          把种植现场、传感器、设备告警和控制命令收进一个 H5 页面，直接连接本地 FastAPI 后端。
        </p>
        <div class="hero__actions" aria-label="首屏操作">
          <a class="hero__button hero__button--ghost" href="#overview">查看总览</a>
          <a class="hero__button hero__button--primary" href="#command-center">进入功能区</a>
        </div>
      </div>

      <div class="hero__status" :class="statusClasses">
        <span>{{ props.systemStatusLabel }}</span>
        <strong>{{ props.fieldRiskLabel }}</strong>
        <small>{{ props.activeAlertCount }} 条待处理告警</small>
        <small>WebSocket：{{ props.wsConnected ? '实时连接中' : '未连接' }}</small>
      </div>

      <div class="hero__timeline" aria-hidden="true">
        <strong>127.0.0.1:8000</strong>
        <span>API / WS connected locally</span>
      </div>
    </div>
  </section>
</template>
