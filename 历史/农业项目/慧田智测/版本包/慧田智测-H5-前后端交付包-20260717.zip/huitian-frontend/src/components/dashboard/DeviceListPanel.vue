<script setup lang="ts">
import { labelDeviceType } from '../../labels'
import { relativeStatusTime } from '../../format'
import type { Device } from '../../types'

defineProps<{
  devices: Device[]
}>()

const selectedDeviceId = defineModel<number | null>('selectedDeviceId', { required: true })

function selectDevice(deviceId: number): void {
  selectedDeviceId.value = deviceId
}
</script>

<template>
  <article class="panel js-entrance">
    <div class="section-heading">
      <div>
        <span class="panel__label">设备列表</span>
        <h2>现场设备</h2>
      </div>
    </div>
    <div v-if="devices.length === 0" class="empty-state">
      <strong>当前地块暂无设备</strong>
      <p>请先在后端初始化演示数据。</p>
    </div>
    <div v-else class="device-list">
      <button
        v-for="device in devices"
        :key="device.id"
        class="device-row"
        :class="{ 'is-selected': selectedDeviceId === device.id }"
        type="button"
        @click="selectDevice(device.id)"
      >
        <span class="status-dot" :class="device.is_online ? 'status-dot--ok' : 'status-dot--idle'"></span>
        <span>
          <strong>{{ device.name }}</strong>
          <small>{{ labelDeviceType(device.device_type) }} · {{ device.device_code }}</small>
        </span>
        <small>{{ relativeStatusTime(device.last_seen_at) }}</small>
      </button>
    </div>
  </article>
</template>
