<script setup lang="ts">
defineProps<{
  refreshing: boolean
}>()

defineEmits<{
  refresh: []
}>()
</script>

<template>
  <section class="toolbar js-entrance" aria-label="系统操作">
    <div>
      <span class="toolbar__label">后端地址</span>
      <strong>127.0.0.1:8000</strong>
    </div>
    <button class="button button--primary" type="button" :disabled="refreshing" @click="$emit('refresh')">
      {{ refreshing ? '刷新中' : '刷新数据' }}
    </button>
  </section>
</template>
