<script setup lang="ts">
import { formatDateTime, formatNumber } from '../../format'
import { labelMetric, labelUnit } from '../../labels'
import type { Farm, HealthResponse, Plot, PlotMetricSummary } from '../../types'

const props = defineProps<{
  health: HealthResponse | null
  selectedFarm: Farm | null
  selectedPlot: Plot | null
  farms: Farm[]
  farmPlots: Plot[]
  onlineDeviceCount: number
  deviceCount: number
  firstSummary: PlotMetricSummary | null
  actionBusy: boolean
}>()

const farmId = defineModel<number | null>('farmId', { required: true })
const plotId = defineModel<number | null>('plotId', { required: true })

const emit = defineEmits<{
  farmChange: []
  plotChange: []
  sendNormal: []
}>()

function handleFarmChange(event: Event): void {
  const value = (event.target as HTMLSelectElement).value
  farmId.value = value ? Number(value) : null
  emit('farmChange')
}

function handlePlotChange(event: Event): void {
  const value = (event.target as HTMLSelectElement).value
  plotId.value = value ? Number(value) : null
  emit('plotChange')
}
</script>

<template>
  <section id="main-content" class="overview-grid js-entrance" aria-label="总览">
    <article class="panel panel--strong">
      <span class="panel__label">系统状态</span>
      <div class="health-row">
        <div>
          <strong>{{ props.health?.status === 'ok' ? '运行正常' : '需要检查' }}</strong>
          <small>{{ props.health?.app ?? '慧田智测' }}</small>
        </div>
        <span class="status-dot" :class="props.health?.status === 'ok' ? 'status-dot--ok' : 'status-dot--bad'"></span>
      </div>
      <dl class="compact-list">
        <div>
          <dt>数据库</dt>
          <dd>{{ props.health?.database ?? '未知' }}</dd>
        </div>
        <div>
          <dt>MQTT</dt>
          <dd>{{ props.health?.mqtt ?? '未知' }}</dd>
        </div>
        <div>
          <dt>更新时间</dt>
          <dd>{{ formatDateTime(props.health?.timestamp) }}</dd>
        </div>
      </dl>
    </article>

    <article class="panel">
      <span class="panel__label">当前地块</span>
      <strong class="panel__big">{{ props.selectedPlot?.name ?? '暂无地块' }}</strong>
      <p>{{ props.selectedFarm?.name ?? '请先初始化演示数据' }}</p>
      <div class="selector-grid">
        <label>
          <span>农场</span>
          <select :value="farmId ?? ''" name="farm_id" autocomplete="off" @change="handleFarmChange">
            <option v-for="farm in props.farms" :key="farm.id" :value="farm.id">{{ farm.name }}</option>
          </select>
        </label>
        <label>
          <span>地块</span>
          <select :value="plotId ?? ''" name="plot_id" autocomplete="off" @change="handlePlotChange">
            <option v-for="plot in props.farmPlots" :key="plot.id" :value="plot.id">
              {{ plot.name }}
            </option>
          </select>
        </label>
      </div>
    </article>

    <article class="panel">
      <span class="panel__label">设备</span>
      <strong class="panel__big">{{ props.onlineDeviceCount }} / {{ props.deviceCount }}</strong>
      <p>在线设备 / 设备总数</p>
      <div class="mini-progress" aria-hidden="true">
        <span :style="{ width: props.deviceCount ? `${(props.onlineDeviceCount / props.deviceCount) * 100}%` : '0%' }"></span>
      </div>
    </article>

    <article class="panel">
      <span class="panel__label">传感器</span>
      <strong class="panel__big">
        <template v-if="props.firstSummary">{{ formatNumber(props.firstSummary.latest) }} {{ labelUnit(props.firstSummary.unit) }}</template>
        <template v-else>暂无</template>
      </strong>
      <p>{{ props.firstSummary ? labelMetric(props.firstSummary.metric) : '上报演示数据后显示' }}</p>
      <button class="button button--ghost" type="button" :disabled="props.actionBusy" @click="emit('sendNormal')">
        上报正常数据
      </button>
    </article>
  </section>
</template>
