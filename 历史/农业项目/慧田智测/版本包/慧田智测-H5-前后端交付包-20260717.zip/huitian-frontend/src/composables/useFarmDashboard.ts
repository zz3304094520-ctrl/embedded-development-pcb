import { computed, shallowRef } from 'vue'
import { api } from '../api'
import { labelCommand, labelCommandStatus } from '../labels'
import type {
  Alert,
  CommandType,
  Device,
  DeviceCommand,
  DiagnosisRecord,
  Farm,
  HealthResponse,
  Plot,
  PlotMetricSummary,
  SensorReading,
  TelemetryPayload,
} from '../types'

export type AlertAction = 'acknowledge' | 'resolve'

export function useFarmDashboard() {
  const loading = shallowRef(true)
  const refreshing = shallowRef(false)
  const actionBusy = shallowRef(false)
  const diagnosisBusy = shallowRef(false)
  const errorMessage = shallowRef('')
  const successMessage = shallowRef('')
  const health = shallowRef<HealthResponse | null>(null)
  const farms = shallowRef<Farm[]>([])
  const plots = shallowRef<Plot[]>([])
  const devices = shallowRef<Device[]>([])
  const readings = shallowRef<SensorReading[]>([])
  const summaries = shallowRef<PlotMetricSummary[]>([])
  const alerts = shallowRef<Alert[]>([])
  const commands = shallowRef<DeviceCommand[]>([])
  const diagnoses = shallowRef<DiagnosisRecord[]>([])
  const selectedFarmId = shallowRef<number | null>(null)
  const selectedPlotId = shallowRef<number | null>(null)
  const selectedDeviceId = shallowRef<number | null>(null)
  const commandDeviceId = shallowRef<number | null>(null)
  const commandType = shallowRef<CommandType>('pump_on')
  const commandDuration = shallowRef(30)
  const diagnosisFile = shallowRef<File | null>(null)

  const selectedFarm = computed(() => farms.value.find((farm) => farm.id === selectedFarmId.value) ?? null)
  const farmPlots = computed(() => {
    if (!selectedFarmId.value) return plots.value
    return plots.value.filter((plot) => plot.farm_id === selectedFarmId.value)
  })
  const selectedPlot = computed(() => plots.value.find((plot) => plot.id === selectedPlotId.value) ?? null)
  const plotDevices = computed(() => devices.value.filter((device) => device.plot_id === selectedPlotId.value))
  const onlineDevices = computed(() => devices.value.filter((device) => device.is_online))
  const activeAlerts = computed(() => alerts.value.filter((alert) => alert.status === 'open'))
  const criticalAlerts = computed(() => activeAlerts.value.filter((alert) => alert.severity === 'critical'))
  const latestReadings = computed(() => readings.value.slice(0, 8))
  const latestCommands = computed(() => commands.value.slice(0, 6))
  const latestDiagnoses = computed(() => diagnoses.value.slice(0, 4))
  const sortedAlerts = computed(() =>
    [...alerts.value].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()),
  )
  const selectedCommandDevice = computed(() => devices.value.find((device) => device.id === commandDeviceId.value) ?? null)
  const canSubmitCommand = computed(() => Boolean(commandDeviceId.value) && !actionBusy.value)
  const canUploadDiagnosis = computed(() => Boolean(selectedPlotId.value && diagnosisFile.value) && !diagnosisBusy.value)
  const firstSummary = computed(() => summaries.value[0] ?? null)
  const systemStatusLabel = computed(() => {
    if (!health.value) return '未连接'
    if (health.value.status === 'ok') return '后端正常'
    return '后端降级'
  })
  const fieldRiskLabel = computed(() => {
    if (criticalAlerts.value.length > 0) return `${criticalAlerts.value.length} 个严重告警`
    if (activeAlerts.value.length > 0) return `${activeAlerts.value.length} 个待处理告警`
    return '当前无待处理告警'
  })

  function setSuccess(message: string): void {
    successMessage.value = message
    window.setTimeout(() => {
      if (successMessage.value === message) successMessage.value = ''
    }, 4200)
  }

  function setError(message: string): void {
    errorMessage.value = message
  }

  function clearError(): void {
    errorMessage.value = ''
  }

  function chooseDefaults(): void {
    if (!selectedFarmId.value || !farms.value.some((farm) => farm.id === selectedFarmId.value)) {
      selectedFarmId.value = farms.value[0]?.id ?? null
    }

    const availablePlots = selectedFarmId.value
      ? plots.value.filter((plot) => plot.farm_id === selectedFarmId.value)
      : plots.value
    if (!selectedPlotId.value || !availablePlots.some((plot) => plot.id === selectedPlotId.value)) {
      selectedPlotId.value = availablePlots[0]?.id ?? null
    }

    const availableDevices = selectedPlotId.value
      ? devices.value.filter((device) => device.plot_id === selectedPlotId.value)
      : devices.value
    if (!selectedDeviceId.value || !availableDevices.some((device) => device.id === selectedDeviceId.value)) {
      selectedDeviceId.value = availableDevices[0]?.id ?? null
    }
    if (!commandDeviceId.value || !availableDevices.some((device) => device.id === commandDeviceId.value)) {
      commandDeviceId.value = availableDevices[0]?.id ?? null
    }
  }

  async function loadCoreData(): Promise<void> {
    const [healthData, farmData, plotData, deviceData, alertData, commandData, diagnosisData] = await Promise.all([
      api.health(),
      api.farms(),
      api.plots(),
      api.devices(),
      api.alerts(),
      api.commands(),
      api.diagnoses(),
    ])

    health.value = healthData
    farms.value = farmData
    plots.value = plotData
    devices.value = deviceData
    alerts.value = alertData
    commands.value = commandData.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    diagnoses.value = diagnosisData.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    chooseDefaults()
  }

  async function loadPlotData(): Promise<void> {
    if (!selectedPlotId.value) {
      readings.value = []
      summaries.value = []
      return
    }

    const [readingData, summaryData, diagnosisData] = await Promise.all([
      api.telemetry({ plotId: selectedPlotId.value, limit: 80 }),
      api.summary(selectedPlotId.value),
      api.diagnoses(selectedPlotId.value),
    ])

    readings.value = readingData.sort((a, b) => new Date(b.recorded_at).getTime() - new Date(a.recorded_at).getTime())
    summaries.value = summaryData
    diagnoses.value = diagnosisData.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
  }

  async function loadAll(): Promise<void> {
    clearError()
    loading.value = true
    try {
      await loadCoreData()
      await loadPlotData()
    } catch (error) {
      setError(error instanceof Error ? error.message : '连接后端失败，请确认后端已经启动。')
    } finally {
      loading.value = false
    }
  }

  async function refreshAll(silent = false): Promise<void> {
    if (!silent) refreshing.value = true
    try {
      await loadCoreData()
      await loadPlotData()
    } catch (error) {
      setError(error instanceof Error ? error.message : '刷新失败，请检查后端服务。')
    } finally {
      refreshing.value = false
    }
  }

  async function onFarmChange(): Promise<void> {
    selectedPlotId.value = farmPlots.value[0]?.id ?? null
    selectedDeviceId.value = null
    commandDeviceId.value = null
    chooseDefaults()
    await loadPlotData()
  }

  async function onPlotChange(): Promise<void> {
    selectedDeviceId.value = plotDevices.value[0]?.id ?? null
    commandDeviceId.value = plotDevices.value[0]?.id ?? null
    await loadPlotData()
  }

  async function submitCommand(): Promise<void> {
    if (!commandDeviceId.value) {
      setError('请选择要控制的设备。')
      return
    }

    actionBusy.value = true
    try {
      const parameters =
        commandType.value === 'pump_on' || commandType.value === 'light_on'
          ? { duration_seconds: commandDuration.value }
          : {}
      const created = await api.createCommand({
        device_id: commandDeviceId.value,
        command_type: commandType.value,
        parameters,
      })
      commands.value = [created, ...commands.value].slice(0, 20)
      setSuccess(`${labelCommand(commandType.value)}命令已创建，当前状态：${labelCommandStatus(created.status)}。`)
    } catch (error) {
      setError(error instanceof Error ? error.message : '创建控制命令失败。')
    } finally {
      actionBusy.value = false
    }
  }

  async function changeAlertStatus(alert: Alert, action: AlertAction): Promise<void> {
    actionBusy.value = true
    try {
      const updated = action === 'acknowledge' ? await api.acknowledgeAlert(alert.id) : await api.resolveAlert(alert.id)
      alerts.value = alerts.value.map((item) => (item.id === updated.id ? updated : item))
      setSuccess(action === 'acknowledge' ? '告警已确认。' : '告警已解决。')
    } catch (error) {
      setError(error instanceof Error ? error.message : '更新告警状态失败。')
    } finally {
      actionBusy.value = false
    }
  }

  function setDiagnosisFile(file: File | null): void {
    diagnosisFile.value = file
  }

  async function uploadDiagnosis(): Promise<void> {
    if (!selectedPlotId.value || !diagnosisFile.value) {
      setError('请选择地块和图片后再上传。')
      return
    }

    diagnosisBusy.value = true
    try {
      const created = await api.uploadDiagnosis(selectedPlotId.value, diagnosisFile.value)
      diagnoses.value = [created, ...diagnoses.value]
      diagnosisFile.value = null
      setSuccess('诊断图片已上传，后端已返回演示诊断结果。')
    } catch (error) {
      setError(error instanceof Error ? error.message : '上传诊断图片失败。')
    } finally {
      diagnosisBusy.value = false
    }
  }

  function buildDemoPayload(kind: 'normal' | 'risk'): TelemetryPayload | null {
    const selected = devices.value.find((device) => device.id === selectedDeviceId.value) ?? plotDevices.value[0]
    if (!selected) {
      setError('当前地块没有设备，无法上报演示数据。')
      return null
    }

    const isSoil = selected.device_type.includes('soil')
    const readingsPayload = isSoil
      ? [
          {
            metric: 'soil_moisture',
            value: kind === 'risk' ? 22 : 46,
            unit: 'percent',
            quality: 'good' as const,
          },
          {
            metric: 'soil_temperature',
            value: kind === 'risk' ? 29.4 : 22.8,
            unit: 'celsius',
            quality: 'good' as const,
          },
        ]
      : [
          {
            metric: 'air_temperature',
            value: kind === 'risk' ? 35.6 : 27.4,
            unit: 'celsius',
            quality: 'good' as const,
          },
          {
            metric: 'air_humidity',
            value: kind === 'risk' ? 68 : 73,
            unit: 'percent',
            quality: 'good' as const,
          },
        ]

    return {
      device_code: selected.device_code,
      recorded_at: new Date().toISOString(),
      readings: readingsPayload,
    }
  }

  async function sendDemoTelemetry(kind: 'normal' | 'risk'): Promise<void> {
    const payload = buildDemoPayload(kind)
    if (!payload) return

    actionBusy.value = true
    try {
      const response = await api.postTelemetry(payload)
      setSuccess(`已上报 ${response.saved_count} 条演示数据，触发 ${response.alert_count} 条告警。`)
      await refreshAll(true)
    } catch (error) {
      setError(error instanceof Error ? error.message : '上报演示数据失败。')
    } finally {
      actionBusy.value = false
    }
  }

  return {
    loading,
    refreshing,
    actionBusy,
    diagnosisBusy,
    errorMessage,
    successMessage,
    health,
    farms,
    plots,
    devices,
    readings,
    summaries,
    alerts,
    commands,
    diagnoses,
    selectedFarmId,
    selectedPlotId,
    selectedDeviceId,
    commandDeviceId,
    commandType,
    commandDuration,
    diagnosisFile,
    selectedFarm,
    farmPlots,
    selectedPlot,
    plotDevices,
    onlineDevices,
    activeAlerts,
    criticalAlerts,
    latestReadings,
    latestCommands,
    latestDiagnoses,
    sortedAlerts,
    selectedCommandDevice,
    canSubmitCommand,
    canUploadDiagnosis,
    firstSummary,
    systemStatusLabel,
    fieldRiskLabel,
    setError,
    clearError,
    loadAll,
    refreshAll,
    onFarmChange,
    onPlotChange,
    submitCommand,
    changeAlertStatus,
    setDiagnosisFile,
    uploadDiagnosis,
    sendDemoTelemetry,
  }
}
