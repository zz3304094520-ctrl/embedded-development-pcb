<script setup lang="ts">
import { nextTick, onMounted, useTemplateRef, watch } from 'vue'
import AlertQueuePanel from './components/dashboard/AlertQueuePanel.vue'
import AppHero from './components/dashboard/AppHero.vue'
import AppToolbar from './components/dashboard/AppToolbar.vue'
import CommandPanel from './components/dashboard/CommandPanel.vue'
import DeviceListPanel from './components/dashboard/DeviceListPanel.vue'
import DiagnosisPanel from './components/dashboard/DiagnosisPanel.vue'
import LoadingGrid from './components/dashboard/LoadingGrid.vue'
import OverviewGrid from './components/dashboard/OverviewGrid.vue'
import RealtimeEventsPanel from './components/dashboard/RealtimeEventsPanel.vue'
import SensorReadingsPanel from './components/dashboard/SensorReadingsPanel.vue'
import SensorSummaryPanel from './components/dashboard/SensorSummaryPanel.vue'
import ToastMessages from './components/dashboard/ToastMessages.vue'
import { useFarmDashboard } from './composables/useFarmDashboard'
import { useInterfaceMotion } from './composables/useInterfaceMotion'
import { useRealtimeEvents } from './composables/useRealtimeEvents'

const dashboard = useFarmDashboard()
const rootEl = useTemplateRef<HTMLElement>('root')
const motion = useInterfaceMotion(rootEl)
const realtime = useRealtimeEvents({
  onRefreshRequested: () => {
    void dashboard.refreshAll(true)
  },
})

watch(dashboard.successMessage, async (value) => {
  if (!value) return
  await nextTick()
  motion.animateSuccessToast()
})

onMounted(async () => {
  await dashboard.loadAll()
  realtime.connectWebSocket()
  await nextTick()
  motion.animateEntrance()
})
</script>

<template>
  <a class="skip-link" href="#main-content">跳到主要内容</a>
  <header class="site-header" aria-label="页面导航">
    <a class="site-logo" href="#top" aria-label="回到顶部">
      <span class="site-logo__mark">田</span>
      <span>慧田智测</span>
    </a>
    <nav class="site-nav" aria-label="功能区导航">
      <a href="#overview">首页</a>
      <a href="#sensors">环境指标</a>
      <a href="#devices">设备</a>
      <a href="#alerts">告警</a>
      <a href="#command-center">命令</a>
      <a href="#diagnosis">诊断</a>
    </nav>
    <a class="site-header__cta" href="#command-center">进入功能区</a>
  </header>
  <main ref="root" class="app-shell">
    <AppHero
      :system-status-label="dashboard.systemStatusLabel.value"
      :field-risk-label="dashboard.fieldRiskLabel.value"
      :ws-connected="realtime.wsConnected.value"
      :active-alert-count="dashboard.activeAlerts.value.length"
      :critical-alert-count="dashboard.criticalAlerts.value.length"
    />

    <ToastMessages
      :error-message="dashboard.errorMessage.value"
      :success-message="dashboard.successMessage.value"
      @dismiss-error="dashboard.clearError"
    />

    <AppToolbar :refreshing="dashboard.refreshing.value" @refresh="dashboard.refreshAll()" />

    <LoadingGrid v-if="dashboard.loading.value" />

    <template v-else>
      <OverviewGrid
        id="overview"
        v-model:farm-id="dashboard.selectedFarmId.value"
        v-model:plot-id="dashboard.selectedPlotId.value"
        :health="dashboard.health.value"
        :selected-farm="dashboard.selectedFarm.value"
        :selected-plot="dashboard.selectedPlot.value"
        :farms="dashboard.farms.value"
        :farm-plots="dashboard.farmPlots.value"
        :online-device-count="dashboard.onlineDevices.value.length"
        :device-count="dashboard.devices.value.length"
        :first-summary="dashboard.firstSummary.value"
        :action-busy="dashboard.actionBusy.value"
        @farm-change="dashboard.onFarmChange"
        @plot-change="dashboard.onPlotChange"
        @send-normal="dashboard.sendDemoTelemetry('normal')"
      />

      <section class="content-grid">
        <SensorSummaryPanel
          id="sensors"
          :summaries="dashboard.summaries.value"
          :action-busy="dashboard.actionBusy.value"
          @send-risk="dashboard.sendDemoTelemetry('risk')"
        />

        <DeviceListPanel
          id="devices"
          v-model:selected-device-id="dashboard.selectedDeviceId.value"
          :devices="dashboard.plotDevices.value"
        />

        <AlertQueuePanel
          id="alerts"
          :alerts="dashboard.sortedAlerts.value"
          :active-alert-count="dashboard.activeAlerts.value.length"
          :action-busy="dashboard.actionBusy.value"
          @change-status="dashboard.changeAlertStatus"
        />

        <CommandPanel
          id="command-center"
          v-model:command-device-id="dashboard.commandDeviceId.value"
          v-model:command-type="dashboard.commandType.value"
          v-model:command-duration="dashboard.commandDuration.value"
          :devices="dashboard.plotDevices.value"
          :commands="dashboard.latestCommands.value"
          :selected-command-device="dashboard.selectedCommandDevice.value"
          :can-submit="dashboard.canSubmitCommand.value"
          :action-busy="dashboard.actionBusy.value"
          @submit-command="dashboard.submitCommand"
        />

        <DiagnosisPanel
          id="diagnosis"
          v-model:file="dashboard.diagnosisFile.value"
          :records="dashboard.latestDiagnoses.value"
          :can-upload="dashboard.canUploadDiagnosis.value"
          :diagnosis-busy="dashboard.diagnosisBusy.value"
          @upload="dashboard.uploadDiagnosis"
        />

        <SensorReadingsPanel id="readings" :readings="dashboard.latestReadings.value" />

        <RealtimeEventsPanel id="realtime" :events="realtime.realtimeEvents.value" :ws-connected="realtime.wsConnected.value" />
      </section>
    </template>
  </main>
</template>
