# Codex 工作记录

## 任务目标

为现有 `huitian-backend` 智慧农业后端制作一个可运行的 H5 前端，前端需要能连接本地 FastAPI 后端，面向非技术用户展示和操作核心功能。

## 产品判断

- 项目是产品型工具界面，不是品牌官网。
- 当前核心用户不是开发者，而是需要演示和理解系统状态的人。
- 首屏必须优先解决“后端是否连上、当前有没有告警、设备是否在线”。
- 前端应作为独立工程放在 `huitian-frontend`，避免改动后端主代码。

## 实施 SOP

1. 安装并检查用户指定的技能仓库。
2. 扫描后端接口、数据模型、演示数据和启动方式。
3. 生成项目级产品上下文 `PRODUCT.md`。
4. 创建独立 H5 前端工程。
5. 用 Vite + Vue 3 + TypeScript 对接 `/api/v1` 和 `/ws`。
6. 做移动端优先布局，覆盖加载、空状态、错误状态、操作反馈。
7. 使用 GSAP 做少量状态反馈动效，避免装饰性动效。
8. 运行安装、类型检查、生产构建。
9. 启动本地页面并做浏览器检查。
10. 把过程中出现的问题记录在本文档，后续不重复踩坑。

## 已安装技能

- `Leonxlnx/taste-skill`：已安装 13 个技能。
- `greensock/gsap-skills`：同名 GSAP 技能已存在；源码已克隆到项目目录。
- `pbakaus/impeccable`：已安装 `impeccable`；源码用稀疏克隆保留技能目录。
- `antfu/skills`：已安装 19 个技能。

源码位置：`F:\workspace\智慧农业\.codex-skill-sources`

## 本次采用的技能约束

- `taste-skill`：避免模板化 UI，锁定产品工具而不是营销页。
- `impeccable`：产品型界面优先清晰、可信、状态完整；避免装饰性动效和过度卡片化。
- `product-design:get-context`：已完成产品、视觉、交互上下文回放；用户明确要求由我按 PM 判断推进，因此未停止等待视觉稿确认。
- `antfu/vue` 与 `antfu/vite`：采用 Vue 3 Composition API、`<script setup lang="ts">`、Vite 配置使用 ESM。
- `gsap-core` 与 `gsap-performance`：动效只使用 transform/opacity，支持 reduced motion，并在卸载时清理。

## 设计方向

Reading this as: product H5 dashboard for farm operators and demo users, with a restrained agricultural operations language, leaning toward Vue/Vite product UI with system typography, deep field-green accent, and compact mobile-first panels.

设计参数：

- DESIGN_VARIANCE: 4
- MOTION_INTENSITY: 3
- VISUAL_DENSITY: 6

原因：这是生产/演示工具，用户要快速判断状态，不需要强烈品牌实验。

## 后端接口摘要

基础地址默认：`http://127.0.0.1:8000`

- `GET /api/v1/health`
- `GET /api/v1/farms`
- `GET /api/v1/plots`
- `GET /api/v1/devices`
- `GET /api/v1/telemetry`
- `GET /api/v1/telemetry/latest/{device_code}`
- `GET /api/v1/telemetry/summary/{plot_id}`
- `GET /api/v1/alerts`
- `POST /api/v1/alerts/{alert_id}/acknowledge`
- `POST /api/v1/alerts/{alert_id}/resolve`
- `GET /api/v1/commands`
- `POST /api/v1/commands`
- `GET /api/v1/diagnosis`
- `POST /api/v1/diagnosis`
- `WS /ws`

## 问题记录和避免规则

### 1. PowerShell 不支持 `Resolve-Path -RelativeBasePath`

现象：安装技能时路径计算失败。

处理：改用字符串截断计算相对路径。

后续规则：在当前 Windows PowerShell 环境中不要再使用 `Resolve-Path -RelativeBasePath`。

### 2. `rg.exe` 被系统拒绝执行

现象：运行 `rg --files` 和 `rg` 搜索时出现 `Access is denied`。

处理：改用 `Get-ChildItem -Recurse` 和 `Select-String`。

后续规则：本项目扫描文件优先使用 PowerShell 原生命令，除非确认 `rg.exe` 恢复可用。

### 3. Windows curl 证书吊销检查失败

现象：`curl` 请求 GitHub API 报 `CRYPT_E_REVOCATION_OFFLINE`。

处理：使用 `curl.exe --ssl-no-revoke`。

后续规则：需要用 Windows curl 访问 GitHub API 时加 `--ssl-no-revoke`。

### 4. `pbakaus/impeccable` 普通 clone 超时

现象：完整克隆超过 180 秒，留下不完整目录。

处理：改用 `git clone --filter=blob:none --depth 1 --sparse`，只拉 `.agents/skills/impeccable`。

后续规则：对大仓库或只需要技能目录的仓库，优先稀疏克隆。

### 5. README 默认读取输出出现乱码

现象：PowerShell 默认输出 README 和旧提示词时出现 mojibake。

处理：代码文件用 `-Encoding UTF8` 读取；业务信息主要从 Python 源码和可读配置确认。

后续规则：不要依赖乱码 README 做精确判断；需要修 README 时先检测原始编码。

### 6. Product Design 与 Impeccable 都有“先确认再实现”的设计门

现象：技能要求先做 brief 或视觉方向确认。

处理：用户明确要求“以产品经理角度分析后开始行动”，因此记录假设并推进可运行 MVP，不让技术/设计流程卡住用户。

后续规则：若后续要做高保真视觉路线、品牌升级或商用交付，再恢复完整的视觉稿确认流程。

### 7. 后端 SQLite 相对路径依赖当前工作目录

现象：从项目根目录直接执行 `huitian-backend\scripts\init_demo_data.py` 时，SQLite 报 `unable to open database file`。

处理：必须把工作目录切到 `huitian-backend` 后运行脚本。

后续规则：后端脚本使用相对 `DATABASE_URL=sqlite:///./data/huitian.db`，执行时一律设置 `workdir=F:\workspace\智慧农业\huitian-backend`。

### 8. 前端浏览器检查发现 favicon 404

现象：Playwright 控制台捕获 `/favicon.ico` 404。

处理：在 `index.html` 加入空 data favicon，避免无意义 404。

后续规则：浏览器验证不只看页面是否渲染，还要看控制台资源错误。

### 9. Playwright CLI `eval` 字符串返回值要避免裸字符串

现象：`playwright-cli eval 'condition ? "OK" : "FAIL"'` 在 PowerShell 环境下会把字符串结果解析成变量，出现 `ReferenceError`。

处理：用布尔表达式或明确可序列化表达式，例如 `document.body.scrollWidth <= window.innerWidth`。

后续规则：Playwright CLI 快速检查优先返回布尔值、数字或 JSON，不返回裸字符串字面量。

### 10. `tsc -b` 项目引用会生成前端根目录副产物

现象：第一次前端构建后生成 `vite.config.js`、`vite.config.d.ts` 和 `*.tsbuildinfo`。

处理：不再用 `vue-tsc -b` 项目引用；改为 `vue-tsc --noEmit --incremental false && tsc -p tsconfig.node.json --noEmit --incremental false && vite build`。

后续规则：前端构建脚本要显式 `--noEmit --incremental false`，避免把类型检查缓存和配置编译产物留在源码根目录。

### 11. `App.vue` 可运行但承担职责过重

现象：MVP 阶段为了快速打通后端，把数据加载、WebSocket、GSAP 动画、表单、列表、告警、诊断等逻辑集中在 `App.vue`。页面可以运行，但后续加功能会继续堆叠，维护风险高。

处理：拆为 3 个 composable 和多个功能组件：

- `useFarmDashboard.ts`：统一管理农场、地块、设备、传感器、告警、命令、诊断和演示上报。
- `useRealtimeEvents.ts`：统一管理 WebSocket 连接、事件队列和实时刷新触发。
- `useInterfaceMotion.ts`：统一管理 GSAP 入场动画、成功提示动画和卸载清理。
- `components/dashboard/*`：按总览、设备、告警、命令、诊断、传感器记录、实时事件拆分 UI。

后续规则：`App.vue` 只作为页面组合层；新增业务能力优先放进对应 composable 和功能组件，不能再把接口请求、WebSocket、表单提交直接堆进 `App.vue`。

### 12. Vue 模板内派生数据要提前计算

现象：MVP 中存在模板里直接过滤地块列表、切片告警列表等写法。数据量小时可用，但会让模板职责变重，也不利于类型检查和后续复用。

处理：把地块过滤、告警截断、列表排序等派生数据移动到 `computed` 或组件脚本中。

后续规则：模板只做声明式渲染；过滤、排序、截断、状态 class 等派生逻辑放在 `<script setup lang="ts">` 里，用 `computed` 表达。

### 13. Vue 组件间通信必须显式 typed props/emits

现象：单文件 MVP 没有组件边界，因此不存在 props/emits 契约；拆分后如果随意传函数或让子组件直接改父级状态，后续会难以定位状态来源。

处理：组件使用 `defineProps`、`defineEmits` 和 `defineModel` 标注输入、事件和双向绑定；文件上传组件使用 `useTemplateRef` 管理文件输入框清空。

后续规则：业务组件必须 props down / events up；只有表单选择值这类明确双向绑定场景才使用 `defineModel`。

### 14. GSAP 动画必须绑定组件生命周期

现象：页面动画如果散落在组件中，容易出现选择器越界、卸载后动画残留、低动效偏好不被尊重的问题。

处理：把 GSAP 集中到 `useInterfaceMotion.ts`，选择器限定在页面根节点内，使用 `prefers-reduced-motion` 降低动画，并在卸载时清理动画上下文。

后续规则：新增动画必须只动 `transform` / `autoAlpha` 这类低成本属性；必须支持 reduced motion；必须有 cleanup。

### 15. Playwright CLI `run-code` 需要传函数

现象：执行 `playwright-cli run-code "await page.emulateMedia(...)"` 报 `SyntaxError: Unexpected identifier 'page'`。

处理：`run-code` 参数必须是一个接收 `page` 的函数，例如 `async (page) => { ... }`。

后续规则：需要调用 Playwright API（例如 `page.emulateMedia`）时，用 `run-code "async (page) => { ... }"`；普通页面表达式仍优先用 `eval`。

### 16. 移动端 resize 后立即读 scrollWidth 可能出现首帧误判

现象：`resize 390 844` 后立刻执行 `document.body.scrollWidth <= window.innerWidth` 曾返回 false，但随后检查 body/html 宽度和越界元素均正常。

处理：改为等待一个 `requestAnimationFrame` 后读取，同时检查 `body` 和 `documentElement` 的 scrollWidth。

后续规则：移动端布局验证使用稳定表达式：`requestAnimationFrame` 后同时确认 `document.body.scrollWidth` 和 `document.documentElement.scrollWidth` 不超过 `window.innerWidth`。

### 17. Playwright snapshot 会生成临时 `.playwright-cli` 目录

现象：执行 snapshot 时 CLI 会在前端目录生成 `.playwright-cli/page-*.yml` 临时快照。

处理：验证完成后确认路径在 `huitian-frontend` 内，再删除 `.playwright-cli`。

后续规则：浏览器验证后要清理 Playwright 临时目录，避免把临时快照当成交付文件留下。

### 18. PowerShell 使用 ZipArchive 需要加载两个程序集

现象：只加载 `System.IO.Compression.FileSystem` 后调用 `[System.IO.Compression.ZipArchiveMode]` 报类型找不到。

处理：同时执行 `Add-Type -AssemblyName System.IO.Compression` 和 `Add-Type -AssemblyName System.IO.Compression.FileSystem` 后再创建 zip。

后续规则：需要用 .NET Zip API 做精确排除打包时，两个 Compression 程序集都要加载；打包完成后检查 zip 条目，确认没有 `.venv`、`node_modules`、`.env`、数据库和临时文件。

## 交付包记录

- 已生成：`F:\workspace\智慧农业\慧田智测-H5-前后端交付包.zip`
- 包内包含：`huitian-backend`、`huitian-frontend`、`交付说明.md`、`PRODUCT.md`、`codex.md`。
- 包内排除：`node_modules`、`.venv`、`dist`、`.env`、后端 `data`、后端 `uploads`、`.pytest_cache`、Playwright 临时目录和技能源码缓存。
- 验证：zip 条目 77 个，确认未包含依赖缓存、虚拟环境、本机数据库和本机 `.env`。

## 苹果风视觉升级记录

- 用户要求：把前端页面再美化，像苹果页面一样简洁高级。
- 处理范围：只改 `huitian-frontend/src/styles.css`，不改后端接口、不改 Vue 组件契约、不改数据流。
- 设计方向：浅灰系统背景、白色内容面板、深色状态岛、克制绿色强调、统一圆角、弱化重阴影、降低边框噪音。
- 避免事项：不做廉价玻璃拟态、不做发光科技大屏、不用 AI 常见紫蓝渐变、不牺牲 H5 可读性。
- 后续规则：此项目产品界面保持 Apple/SF 系统工具感；状态色只用于状态和主操作，不作为装饰；面板避免 `1px border + 大模糊阴影` 的 ghost-card 组合。
- 验证：`npm run typecheck` 通过，`npm run build` 通过；浏览器控制台 0 errors / 0 warnings；390×844 无横向溢出；reduced motion 下无隐藏残留。
- 新截图：
  - `F:\workspace\智慧农业\output\playwright\huitian-h5-apple-mobile.png`
  - `F:\workspace\智慧农业\output\playwright\huitian-h5-apple-desktop.png`

## AIIA 参考风格与梯田背景升级记录

- 用户要求：参考 `https://aiia.douyin.com/` 复刻视觉结构，把背景替换成第三张梯田素材，并把当前项目功能嵌进去。
- 处理原则：不复制第三方站点的品牌、文字、logo、图片和专有素材；只参考其页面结构与交互语言，包括全屏沉浸首屏、固定胶囊导航、中央大标题、底部 CTA、深色内容区。
- 背景素材：采用用户指定第三张梯田图片，复制到 `huitian-frontend/public/media/terrace-particle.jpg`，作为首屏暗色背景和鼠标粒子光场的材质。
- 功能范围：没有新增后端接口；当前农场、地块、设备、告警、命令、诊断、传感器记录、WebSocket 功能继续使用原有 `/api/v1/*` 和 `/ws`。
- 本轮改动：
  - `App.vue` 增加固定导航和功能锚点，锚点指向现有功能组件，不改变组件数据契约。
  - `AppHero.vue` 改为全屏沉浸 Hero，保留后端状态、告警数量和 WebSocket 状态。
  - `styles.css` 改为深色视觉系统，功能区面板、表单、按钮、告警、表格同步改为深色可读版本。
  - 鼠标经过首屏时，背景图、光场、粒子跟随指针做轻量反馈；手机端隐藏漂浮粒子；`prefers-reduced-motion` 下禁用明显动画。
- 验证：
  - `npm run typecheck` 通过。
  - `npm run build` 通过。
  - Playwright 检查本地页面控制台 0 errors / 0 warnings。
  - 390×844 视口无横向溢出，`body/html scrollWidth = 390`。
  - reduced motion 下粒子隐藏，背景不再做 transform 动效。
- 新截图：
  - `F:\workspace\智慧农业\output\playwright\huitian-aiia-style-desktop.png`
  - `F:\workspace\智慧农业\output\playwright\huitian-aiia-style-mobile.png`
  - `F:\workspace\智慧农业\output\playwright\huitian-aiia-style-full.png`
- 交付包：已重新生成 `F:\workspace\智慧农业\慧田智测-H5-前后端交付包.zip`，共 78 个条目；确认不包含 `node_modules`、`.venv`、`dist`、`.env`，并包含 `huitian-frontend/public/media/terrace-particle.jpg`。
- 点击级回归：
  - 顶部导航点击“设备”后能跳转到设备区。
  - “刷新数据”可点击，页面无控制台错误。
  - “上报正常数据”可触发后端遥测写入。
  - “上报告警数据”可触发告警并刷新告警队列。
  - “创建命令”可创建设备命令，列表出现待发送命令。
  - “上传诊断图片”可上传当前梯田素材，后端返回演示诊断结果。
  - WebSocket 面板可见并收到 `command.status_changed`、`alert.created`、`telemetry.created` 等事件。
  - 新截图：`F:\workspace\智慧农业\output\playwright\huitian-aiia-style-after-actions.png`。

### 19. 参考第三方网站时不能直接照搬品牌资产

现象：用户口语化表达“直接复刻”时，容易被理解为复制对方站点的 logo、文字、图片和品牌视觉。

处理：只提取页面结构和动效语言，不使用对方素材；页面品牌仍保持“慧田智测”，背景使用用户给的农业素材。

后续规则：第三方网站只能作为参考，不直接搬运其专有素材、文案、logo、商标和完整视觉识别。

### 20. 大幅重构 Hero 后要清理旧 CSS 类

现象：从局部标题粒子动效改为全屏 Hero 后，旧的 `.hero__material-field` 和 `.hero__material-texture` 媒体查询残留，可能影响后续维护判断。

处理：替换响应式和 reduced-motion 规则，改为新类 `.hero__photo`、`.hero__aurora`、`.hero__code-layer`、`.hero__particle`。

后续规则：重构视觉模块时，除改模板和主样式外，还必须搜索同名前缀的媒体查询、hover 规则和 reduced-motion 规则，确认没有旧实现残留。

## 本轮 v1 维护验证记录

- `npm run typecheck`：通过。
- `npm run build`：通过，Vite 8 生产构建成功。
- 后端健康检查：`GET http://127.0.0.1:8000/api/v1/health` 返回 `status=ok`，数据库 connected，MQTT disconnected 为当前环境预期。
- 浏览器页面：`http://127.0.0.1:5173/` 标题为“慧田智测 H5”，首屏、总览、设备、告警、命令、诊断、传感器记录、WebSocket 面板完整渲染。
- 控制台：Playwright 检查 0 errors，0 warnings。
- 交互验证：点击“上报正常数据”成功新增最新数据并收到 `telemetry.created`；点击“上报告警数据”成功新增告警并收到 `alert.created`；点击“创建命令”成功新增命令并收到 `command.status_changed`。
- 移动端验证：390×844 视口下 body/html 宽度均为 390，无横向溢出。
- Reduced motion 验证：`prefers-reduced-motion: reduce` 下页面正常渲染，`.js-entrance` 无 hidden 残留。
- 临时文件检查：未留下 `.playwright-cli`、`*.tsbuildinfo`、`vite.config.js`、`vite.config.d.ts`。

## 最终验证记录

- `npm install`：通过，0 vulnerabilities。
- `npm run build`：通过，`vue-tsc -b && vite build` 成功。
- 后端健康检查：`GET http://127.0.0.1:8000/api/v1/health` 返回 `status=ok`，数据库 connected，MQTT disconnected 属于无本地 Broker 时的预期状态。
- 前端页面：`http://127.0.0.1:5173` 可打开，页面标题为“慧田智测 H5”。
- 浏览器控制台：Playwright 检查 0 errors，0 warnings。
- 后端连接：页面成功读取农场、地块、设备、传感器、告警、命令和诊断记录。
- WebSocket：页面显示实时连接，收到 `system.connected` 事件。
- 交互验证：点击“上报正常数据”后，后端保存 2 条演示数据，页面出现成功提示并刷新最新数据。
- 移动端检查：390×844 视口下 `document.body.scrollWidth <= window.innerWidth` 为 true，无横向溢出。
