def test_create_command_without_mqtt(client, sample_device):
    response = client.post(
        "/api/v1/commands",
        json={
            "device_id": sample_device["id"],
            "command_type": "pump_on",
            "parameters": {"duration_seconds": 30},
        },
    )
    assert response.status_code == 201
    assert response.json()["status"] == "pending"

    command_id = response.json()["id"]
    ack = client.post(
        f"/api/v1/commands/{command_id}/ack",
        json={"status": "acknowledged"},
    )
    assert ack.status_code == 200
    assert ack.json()["status"] == "acknowledged"

