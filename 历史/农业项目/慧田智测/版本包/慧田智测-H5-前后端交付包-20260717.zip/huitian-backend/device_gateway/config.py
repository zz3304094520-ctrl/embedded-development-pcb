from pydantic_settings import BaseSettings, SettingsConfigDict


class GatewaySettings(BaseSettings):
    mode: str = "http"
    api_base_url: str = "http://127.0.0.1:8000"
    device_code: str = "weather-001"
    interval_seconds: float = 5.0
    mqtt_host: str = "127.0.0.1"
    mqtt_port: int = 1883
    mqtt_topic_prefix: str = "huitian"

    model_config = SettingsConfigDict(env_prefix="GATEWAY_", env_file=".env", extra="ignore")


gateway_settings = GatewaySettings()

