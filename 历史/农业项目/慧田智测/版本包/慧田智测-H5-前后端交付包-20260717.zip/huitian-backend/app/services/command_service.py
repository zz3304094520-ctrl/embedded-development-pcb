from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app import models, schemas


VALID_TRANSITIONS = {
    "pending": {"sent", "acknowledged", "failed"},
    "sent": {"acknowledged", "succeeded", "failed"},
    "acknowledged": {"succeeded", "failed"},
    "succeeded": set(),
    "failed": set(),
}


def create_command(db: Session, data: schemas.CommandCreate) -> models.DeviceCommand:
    if not db.get(models.Device, data.device_id):
        raise HTTPException(status_code=404, detail="设备不存在")
    command = models.DeviceCommand(
        device_id=data.device_id,
        command_type=data.command_type,
        parameters_json=data.parameters,
    )
    db.add(command)
    db.commit()
    db.refresh(command)
    return command


def list_commands(
    db: Session, device_id: int | None = None, status: str | None = None
) -> list[models.DeviceCommand]:
    statement = select(models.DeviceCommand)
    if device_id is not None:
        statement = statement.where(models.DeviceCommand.device_id == device_id)
    if status:
        statement = statement.where(models.DeviceCommand.status == status)
    return list(db.scalars(statement.order_by(models.DeviceCommand.created_at.desc())))


def get_command(db: Session, command_id: int) -> models.DeviceCommand:
    command = db.get(models.DeviceCommand, command_id)
    if not command:
        raise HTTPException(status_code=404, detail="控制命令不存在")
    return command


def update_command_status(
    db: Session, command_id: int, new_status: str
) -> models.DeviceCommand:
    command = get_command(db, command_id)
    if new_status == command.status:
        return command
    if new_status not in VALID_TRANSITIONS.get(command.status, set()):
        raise HTTPException(
            status_code=409,
            detail=f"命令状态不能从 {command.status} 变更为 {new_status}",
        )
    command.status = new_status
    command.updated_at = models.utc_now()
    db.commit()
    db.refresh(command)
    return command

