from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class OrmModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class MessageResponse(BaseModel):
    message: str


class FarmCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    location: str = Field(default="", max_length=200)
    description: str = ""


class FarmUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    location: str | None = Field(default=None, max_length=200)
    description: str | None = None


class FarmResponse(OrmModel):
    id: int
    name: str
    location: str
    description: str
    created_at: datetime


class PlotCreate(BaseModel):
    farm_id: int
    name: str = Field(min_length=1, max_length=100)
    crop_type: str = Field(default="番茄", max_length=50)
    area: float = Field(default=0, ge=0)


class PlotUpdate(BaseModel):
    farm_id: int | None = None
    name: str | None = Field(default=None, min_length=1, max_length=100)
    crop_type: str | None = Field(default=None, max_length=50)
    area: float | None = Field(default=None, ge=0)


class PlotResponse(OrmModel):
    id: int
    farm_id: int
    name: str
    crop_type: str
    area: float
    created_at: datetime


CommunicationType = Literal["http", "mqtt", "rs485_gateway"]


class DeviceCreate(BaseModel):
    plot_id: int
    device_code: str = Field(min_length=1, max_length=100, pattern=r"^[A-Za-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=100)
    device_type: str = Field(min_length=1, max_length=50)
    communication_type: CommunicationType = "http"


class DeviceUpdate(BaseModel):
    plot_id: int | None = None
    name: str | None = Field(default=None, min_length=1, max_length=100)
    device_type: str | None = Field(default=None, min_length=1, max_length=50)
    communication_type: CommunicationType | None = None
    is_online: bool | None = None


class DeviceResponse(OrmModel):
    id: int
    plot_id: int
    device_code: str
    name: str
    device_type: str
    communication_type: str
    is_online: bool
    last_seen_at: datetime | None
    created_at: datetime


class HeartbeatResponse(BaseModel):
    device_code: str
    is_online: bool
    last_seen_at: datetime


class ReadingInput(BaseModel):
    metric: str = Field(min_length=1, max_length=80)
    value: float
    unit: str = Field(default="", max_length=30)
    quality: Literal["good", "suspect", "bad"] = "good"


class TelemetryCreate(BaseModel):
    device_code: str
    recorded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    readings: list[ReadingInput] = Field(min_length=1, max_length=100)

    @field_validator("recorded_at")
    @classmethod
    def recorded_at_must_have_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            raise ValueError("recorded_at 必须包含时区，例如结尾使用 Z")
        return value.astimezone(timezone.utc)


class SensorReadingResponse(OrmModel):
    id: int
    device_id: int
    metric: str
    value: float
    unit: str
    quality: str
    recorded_at: datetime
    received_at: datetime


class TelemetryIngestResponse(BaseModel):
    device_code: str
    saved_count: int
    alert_count: int
    readings: list[SensorReadingResponse]


class LatestTelemetryItem(OrmModel):
    metric: str
    value: float
    unit: str
    quality: str
    recorded_at: datetime


class LatestTelemetryResponse(BaseModel):
    device_code: str
    readings: list[LatestTelemetryItem]


class PlotMetricSummary(BaseModel):
    metric: str
    count: int
    minimum: float
    maximum: float
    average: float
    latest: float
    unit: str


AlertOperator = Literal["gt", "gte", "lt", "lte"]
AlertSeverity = Literal["info", "warning", "critical"]


class AlertRuleCreate(BaseModel):
    plot_id: int
    name: str = Field(min_length=1, max_length=100)
    metric: str = Field(min_length=1, max_length=80)
    operator: AlertOperator
    threshold: float
    severity: AlertSeverity = "warning"
    enabled: bool = True
    message: str = Field(min_length=1, max_length=300)


class AlertRuleUpdate(BaseModel):
    plot_id: int | None = None
    name: str | None = Field(default=None, min_length=1, max_length=100)
    metric: str | None = Field(default=None, min_length=1, max_length=80)
    operator: AlertOperator | None = None
    threshold: float | None = None
    severity: AlertSeverity | None = None
    enabled: bool | None = None
    message: str | None = Field(default=None, min_length=1, max_length=300)


class AlertRuleResponse(OrmModel):
    id: int
    plot_id: int
    name: str
    metric: str
    operator: str
    threshold: float
    severity: str
    enabled: bool
    message: str
    created_at: datetime


class AlertResponse(OrmModel):
    id: int
    rule_id: int
    device_id: int
    reading_id: int
    severity: str
    message: str
    status: str
    created_at: datetime
    updated_at: datetime


CommandType = Literal["pump_on", "pump_off", "light_on", "light_off"]


class CommandCreate(BaseModel):
    device_id: int
    command_type: CommandType
    parameters: dict[str, Any] = Field(default_factory=dict)


class CommandAck(BaseModel):
    status: Literal["acknowledged", "succeeded", "failed"]


class DeviceCommandResponse(OrmModel):
    id: int
    device_id: int
    command_type: str
    parameters_json: dict[str, Any]
    status: str
    created_at: datetime
    updated_at: datetime


class DiagnosisResponse(OrmModel):
    id: int
    plot_id: int
    image_path: str
    crop_type: str
    growth_stage: str
    health_status: str
    result_text: str
    created_at: datetime


class HealthResponse(BaseModel):
    app: str
    status: str
    database: str
    mqtt: str
    timestamp: datetime
