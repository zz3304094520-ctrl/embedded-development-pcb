# 更新记录

## v1.3（2026-09-05）

- 新增 GPIO17 UART2 TX（115200 baud）控制 DSTUR-T20 双路继电器。
- 新增 `pump on/off`、`uvc on/off`、`relay 1/2 on/off`、`relays off` 命令。
- 上电、`arm`、`stop`、`disarm` 和急停时均向两个继电器发送关闭命令。
- `status` 新增 `pump_cmd`、`uvc_cmd` 字段。
- 新增水泵、UVC、继电器及双电机完整接线图。
- 新增 Windows 与 NVIDIA Jetson / Ubuntu 串口操作说明。
- 更新刷写前安全提示：12 V、24 V 全部关闭，ESP32 只保留 USB。

## v1.2（2026-09-04）

- 步进驱动改为双脉冲共阳极方式，SW6=ON。
- GPIO32、GPIO33 分别输出两个方向的有效低脉冲。
- IBT-2 继续使用 GPIO25、GPIO26 和 GPIO27。
