#include <Arduino.h>

// IBT-2 / BTS7960 (brushed DC motor)
constexpr uint8_t PIN_DC_RPWM = 25;
constexpr uint8_t PIN_DC_LPWM = 26;
constexpr uint8_t PIN_DC_EN = 27;  // Wire to both R_EN and L_EN.
constexpr uint8_t DC_PWM_CHANNEL_R = 0;
constexpr uint8_t DC_PWM_CHANNEL_L = 1;
constexpr uint32_t DC_PWM_HZ = 20000;
constexpr uint8_t DC_PWM_BITS = 8;
constexpr uint32_t DC_DEADMAN_MS = 2000;

// LEESN integrated closed-loop stepper, dual-pulse (CW/CCW) mode.
// Set SW6 ON. Common-anode wiring: PUL+ and DIR+ to ESP32 3V3.
// GPIO32 drives PUL- (positive/CW pulses); GPIO33 drives DIR- (negative/CCW pulses).
// Leave EN+ and EN- disconnected; GPIO23 is retained only for backward compatibility.
constexpr uint8_t PIN_STEP_CW = 32;
constexpr uint8_t PIN_STEP_CCW = 33;
constexpr uint8_t PIN_STEP_EN = 23;

// Optional normally-open emergency-stop button: GPIO21 to GND.
// Leave GPIO21 unconnected if this input is not used.
constexpr uint8_t PIN_ESTOP = 21;

// DIUSTOU DSTUR-T20 two-channel serial relay board.
// One-way link: ESP32 GPIO17 (UART2 TX) -> relay RX, with common GND.
// The relay TX pin is intentionally not connected, so reported relay state is
// the last state commanded by this controller rather than physical feedback.
constexpr uint8_t PIN_RELAY_TX = 17;
constexpr uint32_t RELAY_BAUD = 115200;

constexpr uint32_t MIN_STEP_HZ = 1;
constexpr uint32_t MAX_STEP_HZ = 5000;
constexpr uint32_t MAX_STEP_PULSES = 10000000;

bool armed = false;
bool holdAfterMove = false;
bool estopWasActive = false;
int dcPercent = 0;
uint32_t lastDcCommandMs = 0;
bool relayState[2] = {false, false};

struct StepMotion {
  bool active = false;
  bool pulseHigh = false;
  uint8_t pulsePin = PIN_STEP_CW;
  uint32_t pulsesRemaining = 0;
  uint32_t halfPeriodUs = 0;
  uint32_t nextEdgeUs = 0;
} stepMotion;

char commandBuffer[96];
size_t commandLength = 0;

void setRelay(uint8_t channel, bool turnOn) {
  if (channel < 1 || channel > 2) {
    return;
  }

  // DSTUR-T20 frame: A0, channel, operation (00=off, 01=on), checksum.
  const uint8_t operation = turnOn ? 0x01 : 0x00;
  const uint8_t frame[4] = {
      0xA0,
      channel,
      operation,
      static_cast<uint8_t>(0xA0 + channel + operation),
  };
  Serial2.write(frame, sizeof(frame));
  Serial2.flush();
  relayState[channel - 1] = turnOn;
}

void stopRelays() {
  setRelay(1, false);
  delay(5);
  setRelay(2, false);
}

void writeDcDuty(uint8_t rightDuty, uint8_t leftDuty) {
  ledcWrite(DC_PWM_CHANNEL_R, rightDuty);
  ledcWrite(DC_PWM_CHANNEL_L, leftDuty);
}

void stopDc() {
  writeDcDuty(0, 0);
  digitalWrite(PIN_DC_EN, LOW);
  dcPercent = 0;
}

void stopStepper(bool disableDriver) {
  stepMotion.active = false;
  stepMotion.pulseHigh = true;
  stepMotion.pulsesRemaining = 0;
  digitalWrite(PIN_STEP_CW, HIGH);
  digitalWrite(PIN_STEP_CCW, HIGH);
  if (disableDriver) {
    digitalWrite(PIN_STEP_EN, LOW);
  }
}

void disarmAll(const char *reason) {
  stopDc();
  stopStepper(true);
  stopRelays();
  armed = false;
  Serial.print("DISARMED: ");
  Serial.println(reason);
}

void setDcPercent(int percent) {
  percent = constrain(percent, -100, 100);
  writeDcDuty(0, 0);

  if (percent == 0) {
    stopDc();
    Serial.println("DC STOP");
    return;
  }

  const uint8_t duty = map(abs(percent), 0, 100, 0, 255);
  digitalWrite(PIN_DC_EN, HIGH);
  delayMicroseconds(20);

  // The seller's IBT-2 diagram labels LPWM as forward and RPWM as reverse.
  // If the real motor turns the opposite way, swap the motor leads or invert here.
  if (percent > 0) {
    writeDcDuty(0, duty);
  } else {
    writeDcDuty(duty, 0);
  }

  dcPercent = percent;
  lastDcCommandMs = millis();
  Serial.print("DC ");
  Serial.print(percent);
  Serial.println("% (refresh within 2 s)");
}

bool startStepper(int32_t signedPulses, uint32_t frequencyHz) {
  if (signedPulses == 0 || abs(signedPulses) > static_cast<int32_t>(MAX_STEP_PULSES)) {
    Serial.println("ERR pulses must be -10000000..10000000, not 0");
    return false;
  }
  if (frequencyHz < MIN_STEP_HZ || frequencyHz > MAX_STEP_HZ) {
    Serial.println("ERR step frequency must be 1..5000 Hz");
    return false;
  }

  stopStepper(false);
  // In dual-pulse mode the inactive channel must remain HIGH. The selected
  // common-anode '-' input receives active-LOW pulses.
  digitalWrite(PIN_STEP_CW, HIGH);
  digitalWrite(PIN_STEP_CCW, HIGH);
  stepMotion.pulsePin = signedPulses > 0 ? PIN_STEP_CW : PIN_STEP_CCW;
  digitalWrite(PIN_STEP_EN, HIGH);
  delayMicroseconds(100);

  stepMotion.pulsesRemaining = static_cast<uint32_t>(abs(signedPulses));
  stepMotion.halfPeriodUs = 500000UL / frequencyHz;
  if (stepMotion.halfPeriodUs < 2) {
    stepMotion.halfPeriodUs = 2;
  }
  stepMotion.pulseHigh = true;
  stepMotion.nextEdgeUs = micros();
  stepMotion.active = true;

  Serial.print("STEP start pulses=");
  Serial.print(signedPulses);
  Serial.print(" hz=");
  Serial.println(frequencyHz);
  return true;
}

void updateStepper() {
  if (!stepMotion.active) {
    return;
  }

  const uint32_t now = micros();
  if (static_cast<int32_t>(now - stepMotion.nextEdgeUs) < 0) {
    return;
  }

  stepMotion.nextEdgeUs += stepMotion.halfPeriodUs;
  stepMotion.pulseHigh = !stepMotion.pulseHigh;
  digitalWrite(stepMotion.pulsePin, stepMotion.pulseHigh ? HIGH : LOW);

  // One active-low pulse is complete when the selected channel returns HIGH.
  if (stepMotion.pulseHigh) {
    if (stepMotion.pulsesRemaining > 0) {
      --stepMotion.pulsesRemaining;
    }
    if (stepMotion.pulsesRemaining == 0) {
      stepMotion.active = false;
      if (!holdAfterMove) {
        digitalWrite(PIN_STEP_EN, LOW);
      }
      Serial.println("STEP done");
    }
  }
}

void printHelp() {
  Serial.println("Commands:");
  Serial.println("  arm                 enable command acceptance");
  Serial.println("  stop | disarm       immediate stop and disable all");
  Serial.println("  dc <percent>        -100..100; resend within 2 s");
  Serial.println("  step <pulses> <hz>  signed pulses, 1..5000 Hz");
  Serial.println("  hold on|off         stepper hold after move (default off)");
  Serial.println("  pump on|off         relay channel 1 (on requires arm)");
  Serial.println("  uvc on|off          relay channel 2 (on requires arm)");
  Serial.println("  relay <1|2> on|off  generic relay command");
  Serial.println("  relays off          switch both relay channels off");
  Serial.println("  status              show current state");
  Serial.println("  help                 show this text");
}

void printStatus() {
  Serial.print("armed=");
  Serial.print(armed ? "yes" : "no");
  Serial.print(" estop=");
  Serial.print(digitalRead(PIN_ESTOP) == LOW ? "ACTIVE" : "released");
  Serial.print(" dc=");
  Serial.print(dcPercent);
  Serial.print(" step_active=");
  Serial.print(stepMotion.active ? "yes" : "no");
  Serial.print(" step_remaining=");
  Serial.print(stepMotion.pulsesRemaining);
  Serial.print(" hold=");
  Serial.print(holdAfterMove ? "on" : "off");
  Serial.print(" pump_cmd=");
  Serial.print(relayState[0] ? "on" : "off");
  Serial.print(" uvc_cmd=");
  Serial.println(relayState[1] ? "on" : "off");
}

bool processRelayCommand(const String &command) {
  uint8_t channel = 0;
  String action;

  if (command.startsWith("pump ")) {
    channel = 1;
    action = command.substring(5);
  } else if (command.startsWith("uvc ")) {
    channel = 2;
    action = command.substring(4);
  } else {
    int parsedChannel = 0;
    char parsedAction[8] = {};
    if (sscanf(command.c_str(), "relay %d %7s", &parsedChannel, parsedAction) == 2) {
      if (parsedChannel < 1 || parsedChannel > 2) {
        Serial.println("ERR relay channel must be 1 or 2");
        return true;
      }
      channel = static_cast<uint8_t>(parsedChannel);
      action = parsedAction;
    } else {
      return false;
    }
  }

  action.trim();
  if (action == "off") {
    setRelay(channel, false);
    Serial.print(channel == 1 ? "PUMP" : "UVC");
    Serial.println(" relay command OFF");
    return true;
  }
  if (action != "on") {
    Serial.println("ERR relay action must be on or off");
    return true;
  }
  if (!armed) {
    Serial.println("ERR not armed; send: arm");
    return true;
  }

  setRelay(channel, true);
  Serial.print(channel == 1 ? "PUMP" : "UVC");
  Serial.println(" relay command ON");
  return true;
}

void processCommand(char *line) {
  String command(line);
  command.trim();
  command.toLowerCase();
  if (command.length() == 0) {
    return;
  }

  if (command == "help" || command == "?") {
    printHelp();
    return;
  }
  if (command == "status") {
    printStatus();
    return;
  }
  if (command == "stop" || command == "disarm") {
    disarmAll("user command");
    return;
  }
  if (command == "relays off") {
    stopRelays();
    Serial.println("RELAYS command OFF");
    return;
  }
  if (command == "arm") {
    if (digitalRead(PIN_ESTOP) == LOW) {
      Serial.println("ERR release E-STOP first");
      return;
    }
    stopDc();
    stopStepper(true);
    stopRelays();
    armed = true;
    Serial.println("ARMED; outputs remain stopped until dc/step command");
    return;
  }

  if (command.startsWith("hold ")) {
    const String value = command.substring(5);
    if (value == "on") {
      holdAfterMove = true;
      Serial.println("HOLD on");
    } else if (value == "off") {
      holdAfterMove = false;
      if (!stepMotion.active) {
        digitalWrite(PIN_STEP_EN, LOW);
      }
      Serial.println("HOLD off");
    } else {
      Serial.println("ERR use: hold on|off");
    }
    return;
  }

  if (processRelayCommand(command)) {
    return;
  }

  if (!armed) {
    Serial.println("ERR not armed; send: arm");
    return;
  }

  int percent = 0;
  if (sscanf(command.c_str(), "dc %d", &percent) == 1) {
    if (percent < -100 || percent > 100) {
      Serial.println("ERR dc percent must be -100..100");
      return;
    }
    setDcPercent(percent);
    return;
  }

  long pulses = 0;
  unsigned long frequencyHz = 0;
  if (sscanf(command.c_str(), "step %ld %lu", &pulses, &frequencyHz) == 2) {
    startStepper(static_cast<int32_t>(pulses), static_cast<uint32_t>(frequencyHz));
    return;
  }

  Serial.println("ERR unknown command; send: help");
}

void readSerialCommands() {
  while (Serial.available() > 0) {
    const char c = static_cast<char>(Serial.read());
    if (c == '\r') {
      continue;
    }
    if (c == '\n') {
      commandBuffer[commandLength] = '\0';
      processCommand(commandBuffer);
      commandLength = 0;
      continue;
    }
    if (commandLength < sizeof(commandBuffer) - 1) {
      commandBuffer[commandLength++] = c;
    } else {
      commandLength = 0;
      Serial.println("ERR command too long");
    }
  }
}

void setup() {
  // Establish safe hardware states before initializing any peripheral.
  pinMode(PIN_DC_EN, OUTPUT);
  digitalWrite(PIN_DC_EN, LOW);
  pinMode(PIN_DC_RPWM, OUTPUT);
  pinMode(PIN_DC_LPWM, OUTPUT);
  digitalWrite(PIN_DC_RPWM, LOW);
  digitalWrite(PIN_DC_LPWM, LOW);

  pinMode(PIN_STEP_EN, OUTPUT);
  digitalWrite(PIN_STEP_EN, LOW);
  pinMode(PIN_STEP_CW, OUTPUT);
  pinMode(PIN_STEP_CCW, OUTPUT);
  digitalWrite(PIN_STEP_CW, HIGH);
  digitalWrite(PIN_STEP_CCW, HIGH);

  pinMode(PIN_ESTOP, INPUT_PULLUP);

  Serial2.begin(RELAY_BAUD, SERIAL_8N1, -1, PIN_RELAY_TX);
  delay(20);
  stopRelays();

  ledcSetup(DC_PWM_CHANNEL_R, DC_PWM_HZ, DC_PWM_BITS);
  ledcSetup(DC_PWM_CHANNEL_L, DC_PWM_HZ, DC_PWM_BITS);
  ledcAttachPin(PIN_DC_RPWM, DC_PWM_CHANNEL_R);
  ledcAttachPin(PIN_DC_LPWM, DC_PWM_CHANNEL_L);
  writeDcDuty(0, 0);

  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println("ESP32 dual motor + relay controller v1.3 (stepper dual-pulse common-anode)");
  Serial.println("SAFE BOOT: motors disabled; both relay channels commanded off");
  printHelp();
}

void loop() {
  const bool estopActive = digitalRead(PIN_ESTOP) == LOW;
  if (estopActive && !estopWasActive) {
    disarmAll("E-STOP");
  } else if (!estopActive && estopWasActive) {
    Serial.println("E-STOP released; send arm to continue");
  }
  estopWasActive = estopActive;

  if (dcPercent != 0 && millis() - lastDcCommandMs > DC_DEADMAN_MS) {
    stopDc();
    Serial.println("DC DEADMAN STOP (no refresh for 2 s)");
  }

  updateStepper();
  readSerialCommands();
}
