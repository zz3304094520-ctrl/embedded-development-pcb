# ESP32 双电机与双路继电器控制器 v1.3 分享包

更新时间：2026-09-05

本包适用于以下已实机验证的组合：

- ESP32 Dev Module（经典 ESP32，4 MB Flash，CP210x USB 串口）
- 立三 57 一体式闭环步进电机，脉冲控制款
- IBT-2 / BTS7960 H 桥
- 24 V 5840 蜗轮蜗杆永磁直流减速电机
- DIUSTOU / DSTUR-T20 双路 TTL 串口继电器板
- 12 V、60 W 自吸式直流隔膜水泵（继电器第 1 路）
- 12 V、4 W UVC 杀菌灯（继电器第 2 路）

v1.3 在 v1.2 双电机功能上增加了 GPIO17 单向串口控制双路继电器。实机已确认两个继电器可以分别亮灯、吸合和关闭；这是空载触点测试，不代表水泵和 UVC 负载已经完成长期可靠性测试。

## 一、安全要求

1. 接线、改线或改变拨码前，必须关闭 12 V、24 V，并拔掉 ESP32 USB。
2. **刷固件时断开 ESP32 的所有外接线，只保留 USB。** 实机曾因外接线路导致 Flash 通信和写入校验失败。
3. 12 V、24 V 和 5 V 不得接入 ESP32 GPIO；GPIO 只允许 3.3 V 逻辑电平。
4. 水泵是感性负载且启动电流较大，建议使用至少 12 V / 10 A 的可靠电源、水泵支路保险丝，并在水泵端并联合适的续流二极管（阴极接泵正极，阳极接泵负极）。
5. UVC 灯包含 254 nm 紫外线及 185 nm 臭氧：只能在无人、无动物、遮光条件下工作；结束后充分通风。不得直视或照射皮肤。
6. 首次带载测试应短时间进行，并准备可直接切断 12 V、24 V 的总电源开关或急停。
7. IBT-2 标注的 43 A 是峰值宣传参数，持续工作能力取决于散热、端子和线径。

## 二、完整接线图

优先查看：

- `docs/ESP32_完整接线图_v1.3.png`：高清图片
- `docs/ESP32_完整接线图_v1.3.svg`：可放大、可编辑矢量图

## 三、步进电机接线

拨码：**SW6=ON（双脉冲模式）**。改变拨码后应完全断电约 10 秒再上电。

| 步进一体机端子 | 连接位置 | 说明 |
|---|---|---|
| V+ | 24 V 电源正极 | 电机动力电源 |
| V- | 24 V 电源负极 | 电机动力电源 |
| PU+ | ESP32 3V3 | 与 DR+ 并联，共阳极 |
| PU- | ESP32 GPIO32 | 正向脉冲 |
| DR+ | ESP32 3V3 | 与 PU+ 并联，共阳极 |
| DR- | ESP32 GPIO33 | 反向脉冲 |
| EN+、EN- | 不连接 | 两端均悬空 |
| AL+、AL- | 可不连接 | 报警输出，本固件未使用 |

GPIO23 不需要外接。若实际机械正反方向与命令符号相反，可交换 GPIO32 与 GPIO33 对应的两根脉冲线，或在源码中反转方向定义。

## 四、IBT-2 与 24 V 减速电机接线

| IBT-2 端子 | 连接位置 |
|---|---|
| B+ | 24 V 电源正极 |
| B- | 24 V 电源负极 |
| M+、M- | 直流减速电机两根线 |
| VCC | ESP32 5V/VIN |
| GND | ESP32 GND |
| RPWM | ESP32 GPIO25 |
| LPWM | ESP32 GPIO26 |
| R_EN、L_EN | 两端并联后接 ESP32 GPIO27 |
| R_IS、L_IS | 不连接 |

ESP32 GND、IBT-2 控制 GND 和 24 V 电源负极应可靠共地。交换 M+、M- 可改变直流电机的物理方向。

## 五、DSTUR-T20 双路继电器接线

### 控制端

| 继电器板端子 | 连接位置 | 说明 |
|---|---|---|
| 5V | ESP32 5V/VIN | 继电器板逻辑和线圈供电 |
| GND | ESP32 GND | 控制端共地 |
| RX | ESP32 GPIO17 | 建议串联约 1 kΩ；UART2 TX，115200 baud |
| TX | 不连接 | 当前采用单向控制 |
| USB-C | 不连接 | 使用针脚 5V 时不要再接 USB-C，避免双电源 |

由于 TX 未接，ESP32 的 `pump_cmd` 和 `uvc_cmd` 仅代表最后发出的命令，不能证明继电器触点或负载实际工作。

### 12 V 水泵（第 1 路，默认断电）

1. 12 V 电源正极 → `COM1`
2. `NO1`（板上也可能印作 `ON1`）→ 水泵正极
3. 水泵负极 → 12 V 电源负极
4. `NC1` 不连接

### 12 V UVC 灯（第 2 路，默认断电）

1. 12 V 电源正极 → `COM2`
2. `NO2`（板上也可能印作 `ON2`）→ UVC 正极
3. UVC 负极 → 12 V 电源负极
4. `NC2` 不连接

水泵和 UVC 的 12 V 动力回路不接 ESP32 5V。继电器触点相当于独立开关，因此 12 V 负极无需为了触点本身连接 ESP32 GND。

## 六、刷写固件（Windows）

推荐固件：`firmware/esp32_motor_relay_v1.3_full.bin`。它已合并 bootloader、分区表和应用程序，从地址 `0x0` 写入。

准备步骤：

1. 关闭 12 V、24 V，拔掉 ESP32 的全部外接线，只保留 USB。
2. 安装 Python，然后执行：`py -m pip install esptool`
3. 打开 PowerShell 并进入本分享包目录。
4. 如系统限制脚本，执行：`Set-ExecutionPolicy -Scope Process Bypass`
5. 执行：`.\flash_firmware.ps1 -Port COM3`

接收方的串口不一定是 COM3，可在 Windows 设备管理器查看并替换，例如 `-Port COM5`。

熟悉 esptool 的用户也可执行：

```powershell
py -m esptool --chip esp32 --port COM3 --baud 115200 write_flash 0x0 .\firmware\esp32_motor_relay_v1.3_full.bin
```

## 七、串口控制命令

参数：115200 baud、8N1、LF 换行。

| 命令 | 功能 |
|---|---|
| `status` | 查看控制器状态 |
| `arm` | 允许运动和继电器开启；本命令本身不会启动负载 |
| `stop` 或 `disarm` | 立即停止电机、关闭两路继电器并解除使能 |
| `step 500 100` | 步进正向 500 脉冲、100 Hz，约 5 秒 |
| `step -500 100` | 步进反向 500 脉冲、100 Hz，约 5 秒 |
| `hold on` / `hold off` | 步进结束后保持/释放（默认释放） |
| `dc 40` | 直流电机一个方向，40% PWM |
| `dc -40` | 直流电机相反方向，40% PWM |
| `dc 0` | 停止直流电机 |
| `pump on` / `pump off` | 开启/关闭继电器第 1 路 |
| `uvc on` / `uvc off` | 开启/关闭继电器第 2 路 |
| `relay 1 on/off` | 第 1 路通用命令 |
| `relay 2 on/off` | 第 2 路通用命令 |
| `relays off` | 无需 `arm`，立即发送两路关闭命令 |
| `help` | 显示命令帮助 |

上电默认 `armed=no`，电机停止并向两路继电器发送关闭命令。所有 `on` 和运动命令都必须先发送 `arm`；关闭命令不要求 `arm`。

直流电机设有 2 秒看门狗：运行时必须每 2 秒以内重复发送一次 `dc` 命令，否则自动停止。继电器当前没有自动关闭计时，使用方必须保证最终发送 `pump off`、`uvc off` 或 `stop`。

### Windows 串口终端

```powershell
py -m pip install pyserial
py -m serial.tools.miniterm --echo --eol LF COM3 115200
```

退出 miniterm：按 `Ctrl+]`。

### NVIDIA Jetson / Ubuntu 串口终端

先确认设备名：

```bash
ls -l /dev/ttyUSB* /dev/ttyACM* 2>/dev/null
```

如果 ESP32 是 `/dev/ttyUSB0`：

```bash
sudo apt install python3-serial
python3 -m serial.tools.miniterm --echo --eol LF /dev/ttyUSB0 115200
```

若提示权限不足，可执行 `sudo usermod -aG dialout $USER`，注销并重新登录后再试。

## 八、已验证情况

- ESP32 USB 串口、`status`、`arm`、`stop` 正常。
- 步进驱动器 SW6=ON，双脉冲正反方向分别有效。
- IBT-2 驱动 24 V 减速电机正反方向有效。
- DSTUR-T20 第 1、2 路均完成空载短测：分别亮灯、发出“咔嗒”声并成功关闭。
- 安全状态确认：`armed=no`、`dc=0`、`pump_cmd=off`、`uvc_cmd=off`。

## 九、目录内容

- `firmware/esp32_motor_relay_v1.3_full.bin`：推荐刷写的完整固件
- `firmware/firmware_app_v1.3.bin`：仅应用程序，写入地址 `0x10000`
- `firmware/bootloader.bin`、`partitions.bin`、`boot_app0.bin`：独立分区文件
- `source/`：PlatformIO 源码
- `docs/`：接线图、ESP32 说明书和步进驱动器参考说明书
- `flash_firmware.ps1`：Windows 一键刷写脚本
- `SHA256SUMS.txt`：文件完整性校验值

注意：DE57 PDF 是同系列驱动器参考资料，最终以实物端子标识、本 README 和实机验证接法为准。
