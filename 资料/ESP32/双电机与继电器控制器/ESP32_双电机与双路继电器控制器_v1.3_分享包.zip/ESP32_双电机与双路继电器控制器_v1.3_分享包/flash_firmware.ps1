param(
    [string]$Port = "COM3"
)

$ErrorActionPreference = "Stop"
$firmware = Join-Path $PSScriptRoot "firmware\esp32_motor_relay_v1.3_full.bin"

if (-not (Test-Path -LiteralPath $firmware)) {
    throw "Firmware file not found: $firmware"
}

$launcher = $null
if (Get-Command py -ErrorAction SilentlyContinue) {
    $launcher = (Get-Command py).Source
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $launcher = (Get-Command python).Source
} else {
    throw "Python not found. Install Python first, then run: py -m pip install esptool"
}

& $launcher -m esptool version
if ($LASTEXITCODE -ne 0) {
    throw "esptool is not installed. Run: py -m pip install esptool"
}

Write-Host ""
Write-Host "WARNING: Turn OFF 12 V and 24 V, then disconnect every external wire from the ESP32."
Write-Host "Leave only the USB cable connected. Selected port: $Port"
$answer = Read-Host "Type USB-ONLY to continue"
if ($answer -ne "USB-ONLY") {
    Write-Host "Cancelled. Nothing was written."
    exit 1
}

& $launcher -m esptool --chip esp32 --port $Port --baud 115200 write_flash 0x0 $firmware
if ($LASTEXITCODE -ne 0) {
    throw "Flashing failed. Keep all external power off, check the USB cable and COM port, then retry."
}

Write-Host ""
Write-Host "Flash completed successfully."
Write-Host "Reconnect hardware only while USB, 12 V and 24 V are all OFF."
